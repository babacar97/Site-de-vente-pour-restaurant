/*
 *  @Website: apollotheme.com - prestashop template provider
 *  @author Apollotheme <apollotheme@gmail.com>
 *  @copyright  Apollotheme
 *  @description: 
 */

$(document).ready(function() {
    if (typeof autoload_func_name !== 'undefined') {
        window[autoload_func_name]();
    }
});
